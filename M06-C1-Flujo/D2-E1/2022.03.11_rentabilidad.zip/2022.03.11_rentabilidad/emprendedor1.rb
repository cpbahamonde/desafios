precio_ventas = ARGV[0].to_f
usuarios = ARGV[1].to_f
gastos = ARGV[2].to_f
impuestos = 0.35

utilidades = (precio_ventas * usuarios - gastos) * (1 - impuestos)

puts "Las utilidades que generará son $#{utilidades}"
