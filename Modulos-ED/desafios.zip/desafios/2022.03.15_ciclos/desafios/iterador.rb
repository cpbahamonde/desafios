i = 0

50.times do
    puts "Iteración #{i}"
    i += 1
end   