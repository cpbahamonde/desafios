class LibrosController < ApplicationController
  def index
  end

  def prestamo
  end
end
