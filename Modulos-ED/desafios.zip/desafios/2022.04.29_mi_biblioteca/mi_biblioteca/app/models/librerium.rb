class Librerium < ApplicationRecord
end
