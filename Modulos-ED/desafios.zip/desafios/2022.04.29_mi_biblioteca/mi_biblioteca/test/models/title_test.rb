require "test_helper"

class TitleTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
