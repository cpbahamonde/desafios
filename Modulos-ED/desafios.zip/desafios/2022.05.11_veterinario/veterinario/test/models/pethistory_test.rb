require "test_helper"

class PethistoryTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
